package com.cg.bankwallet.dao;

import java.util.ArrayList;

import com.cg.bankwallet.bean.BankWalletBean;

public interface IBankWalletDao 
{
	
	public BankWalletBean createAccount(BankWalletBean c);
	public double showBalance(String accountNumber);
	public double deposit(String accountNumber,double amount);
	public double withDraw(String accountNumber,double amount);
	public double fundTransfer(String accountNumbergSource,String accountNumberTarget,double amount);
	public ArrayList<BankWalletBean>  printTranscations(String accountNumber);
}
